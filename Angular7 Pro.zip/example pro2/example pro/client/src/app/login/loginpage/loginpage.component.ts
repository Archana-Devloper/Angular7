import { Component, OnInit } from '@angular/core';
import { FormserviceService } from '../../formservice.service';
import { ActivatedRoute, Params, Router, NavigationExtras } from '@angular/router';
@Component({
  selector: 'app-loginpage',
  templateUrl: './loginpage.component.html',
  styleUrls: ['./loginpage.component.css']
})
export class LoginpageComponent implements OnInit {

  constructor(private form:FormserviceService,private router: Router) { }
  model:any=[
   
  ]

  submit(model){
  debugger
  if(!model.firstname){
    alert('please fill firstname')
  }
  if(model.firstname){

  localStorage.setItem("firstname",model.firstname)
 
  this.form.login(model).subscribe(data=>{

  })
  this.router.navigate(['dashboard'])
  }
}
  users:any=[]
  get(){
    debugger
    this.form.get1().subscribe(data=>{
      this.users=data

    })
  }

  ngOnInit() {
    this.get();
  }

}
