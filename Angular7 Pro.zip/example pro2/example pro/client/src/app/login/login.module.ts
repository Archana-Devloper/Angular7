import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import{FormsModule} from '@angular/forms'

import { LoginRoutingModule } from './login-routing.module';
import { LoginpageComponent } from './loginpage/loginpage.component';
import { AuthGuard } from '../gaurds/auth.guard';

@NgModule({
  declarations: [LoginpageComponent],
  imports: [
    CommonModule,
    LoginRoutingModule,FormsModule
  ] ,
  providers: [AuthGuard],
})
export class LoginModule { }
