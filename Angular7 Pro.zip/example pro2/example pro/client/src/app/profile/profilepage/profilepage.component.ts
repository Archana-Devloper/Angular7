import { Component, OnInit } from '@angular/core';
import { FormserviceService } from 'src/app/formservice.service';
import { ActivatedRoute, Params, Router, NavigationExtras } from '@angular/router';
import { checkAndUpdateBinding } from '@angular/core/src/view/util';
@Component({
  selector: 'app-profilepage',
  templateUrl: './profilepage.component.html',
  styleUrls: ['./profilepage.component.css']
})
export class ProfilepageComponent implements OnInit {

  constructor(private form:FormserviceService,private router: Router) { }
  model:any=[ ]
  check(file: any) {

    this.imageType = file.target.files[0].type

    this.profileimage.type = this.imageType.replace("image/", ".")

    if (file.target.files.length) {


      if (this.imageType == "image/jpeg" || this.imageType == "image/jpg" || this.imageType == "image/png" || this.imageType == "image/gif") {
        var reader = new FileReader();
        reader.readAsDataURL(file.target.files[0]); // read file as data url
        reader.onload = (ev: any) => { // called once readAsDataURL is completed
          this.profileimage.img_data = ev.target.result;

          this.profileimage.img_data = this.profileimage.img_data.replace("data:" + this.imageType + ";base64,", "");
          this.model.image=this.profileimage
        }


      }
    }
  }
  profileimage = {
    type: '',
    img_data: ''
  }
  imageType
  email:any
  mobile:any
  image:any
  submit(model){
   
    if(model.name && model.email && model.mobile){
    localStorage.setItem("name",model.name)
    localStorage.setItem("image",model.image)
    localStorage.setItem("email",model.email)
    localStorage.setItem("mobile",model.mobile)

debugger
 console.log(model)
 
  this.form.proifle(model).subscribe(data=>{
    
  
 
 


  })
  // console.log(localStorage.getItem(name),localStorage.getItem(email),)
  alert('profile details updated successfully')
  }
}

logout(){
  localStorage.clear()
  this.router.navigate([''])
}
  ngOnInit() {
    debugger
    this.model.name=localStorage.getItem('name');
   
    this.model.email=localStorage.getItem('email');
    this.model.mobile=localStorage.getItem('mobile');
   
  
    this.model.image=localStorage.getItem('image')
  }

}

