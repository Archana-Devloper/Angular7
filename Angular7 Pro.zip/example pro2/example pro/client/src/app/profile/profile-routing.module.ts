import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { ProfilepageComponent} from '../profile/profilepage/profilepage.component'
import { AuthGuard } from '../gaurds/auth.guard';
import { HttpClientModule } from '@angular/common/http'; 
const routes: Routes = [

  { path:'',component:ProfilepageComponent,canActivate:[AuthGuard]}
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
  ,
  providers: [AuthGuard],
})
export class ProfileRoutingModule { }
