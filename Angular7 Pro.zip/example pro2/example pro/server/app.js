var express = require('express');
var promise = require('bluebird');
var bodyParser = require('body-parser');

var options = {
    // Initialization Options
    promiseLib: promise
};

var pgp = require('pg-promise')(options);

var app = new express();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// var connectionString = 'postgres://postgres:root@localhost:5432/practice';
// var db = pgp(connectionString);
app.use(function (req, res, next) {
    // Website you wish to allow to connect
    res.setHeader('Access-Control-Allow-Origin', '*');
  
    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');
  
    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');
  
    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);
  
    // Pass to next layer of middleware
    next();
  });
app.get('/get', (req, res, next) => {
    db.any('select * from  practice')
        .then(function (data) {
            console.log(data);
            res.send(data);
        })
})
app.post('/post', (req, res, next) => {
    var n = req.body.fn;
    var nm = req.body.ln;
    console.log(n,nm);
    // db.none('insert into practice values($1,$2)', [n, nm]).then(function () {
    //     console.log('Record Inserted ...')
    //     res.status(200).send({message:"Inserted Suxces.."})
    // })
})

app.post('/prof', (req, res, next) => {
    var n = req.body.name;
    var em = req.body.email;
    var mob = req.body.mobile;
    var f=req.body.file;
    console.log(n,em,mob,f);
    // db.none('insert into practice values($1,$2,$3)', [n, em, mob,f]).then(function () {
    //     console.log('Record Inserted ...')
    //     res.status(200).send({message:"Inserted Suxces.."})
    // })
})


app.listen(4400, (err) => {
    if (err) {
        console.log('Unable to start server ...')
    }
    else {
        console.log('server Started at : ' + 'http://localhost:4400/')
    }
})
